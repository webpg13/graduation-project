<template>
    <div>
        <img alt="Vue logo" src="../../assets/logo.png">
        欢迎！
    </div>
</template>
